<!DOCTYPE html>
<html>
<head>
    <title>Login Page</title>
    <link rel="stylesheet" type="text/css" href="css/slide_navbar.css">
<link href="https://fonts.googleapis.com/css2?family=Jost:wght@500&display=swap" rel="stylesheet">
</head>
<body>
    <div class="main"> 

        <input type="checkbox" id="chk" aria-hidden="true">

            <div class="login">
                <form method="POST" action="login_process2.php">
                    <label for="chk" aria-hidden="true">Login</label>
                    <input type="email" name="email" placeholder="Email" required="">
                    <input type="password" name="pwd" placeholder="Password" required="">
                    <button type="submit" name="login" id="login">Login</button>
                </form>
            </div>

            <div class="signup">
                <form method="POST" action="login_process2.php">
                    <label for="chk" aria-hidden="true">Sign up</label>
                    <input type="email" name="email" placeholder="Email or Number" required="">
                    <input type="password" name="pwd" placeholder="Password" required="">
                    <button type="submit" name="signup" id="signup">Sign up</button>
                </form>
            </div>
    </div>
</body>
</html>