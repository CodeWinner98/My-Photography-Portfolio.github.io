<?php 

function createconn(){
	$host='localhost';
	$username="root";
	$password="";
	$dbname="myweb_db";

	$conn = new mysqli($host,$username,$password,$dbname);

	if($conn->connect_error){
		die("Connection Failed: ".$conn->connect_error);
	}

	return $conn;
}

function register($user_name, $pwd) {
    $conn = createconn();
    $hashedPassword = password_hash($pwd, PASSWORD_DEFAULT);

    // Insert user details
    $query = "INSERT INTO login (user_name, password) VALUES (?, ?)";
    $stmt = $conn->prepare($query);

    // Corrected line: Added $stmt before bind_param
    $stmt->bind_param("ss", $user_name, $hashedPassword);

    if ($stmt->execute()) {
        return true; // Registration successful
    } else {
        return false; // Registration failed
    }
}


function login($user_name,$pwd){
	$conn=createconn();
	$query = "SELECT password FROM login WHERE user_name=?";
	$stmt = $conn->prepare($query);
    $stmt->bind_param("s", $user_name);
    $stmt->execute();
    $stmt->bind_result($hashedPassword);
    $stmt->fetch();

    // Verify the password
    if (password_verify($pwd, $hashedPassword)) {
        return true; // Login successful
    } else {
        return false; // Login failed
    }
}

?>