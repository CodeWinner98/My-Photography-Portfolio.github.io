<?php
//Create database connection
function createconn(){
	$host='localhost';
	$username="root";
	$password="";
	$dbname="myweb_db";

	$conn = new mysqli($host,$username,$password,$dbname);

	if($conn->connect_error){
		die("Connection Failed: ".$conn->connect_error);
	}

	return $conn;
}

//booking 
function insert_booking($name,$tele,$addr,$event,$date,$email,$more ){
	$conn = createconn();
	$name = $conn->real_escape_string($name);
	$tele = $conn->real_escape_string($tele);
	$addr = $conn->real_escape_string($addr);
	$event= $conn->real_escape_string($event);
	$date = $conn->real_escape_string($date);
	$email= $conn->real_escape_string($email);
	$more = $conn->real_escape_string($more);

	$sql = "INSERT INTO booking_tb (Name,Tele_Number,Address,Event,Date,Email,More) VALUES('$name','$tele','$addr','$event','$date','$email','$more')";
	if($conn->query($sql)==TRUE){
		echo "Booking was successful!";
	}
	else{
		echo "Error while booking.";
	}
}

//show booking details
function show_booking(){
	$conn = createconn();
	$sql  = "SELECT * FROM booking_tb";
	$result = $conn->query($sql);
	$projects = [];

	if($result->num_rows>0){
		while($row = $result->fetch_assoc()){
			$projects[] = $row;
		}
	}

	return $projects;
}

//update details
function update_booking($id,$name,$tele,$addr,$event,$date,$email,$more){
	$conn = createconn();
	
	$name = $conn->real_escape_string($name);
	$tele = $conn->real_escape_string($tele);
	$addr = $conn->real_escape_string($addr);
	$event= $conn->real_escape_string($event);
	$date = $conn->real_escape_string($date);
	$email= $conn->real_escape_string($email);
	$more = $conn->real_escape_string($more);

	$sql = "UPDATE booking_tb SET 
	Name        ='$name' ,
	Tele_Number ='$tele',
	Address     ='$addr',
	Event       ='$event',
	Date        ='$date',
	Email       ='$email',
	More        ='$more' 
	WHERE ID=$id";

	 if($conn->query($sql)==TRUE){
		echo "Update was successful!";
	}
	else{
		echo "Error while updating.";
	}

}

//delete details
function delete_booking($id){
	$conn = createconn();
    $sql = "DELETE FROM booking_tb WHERE ID=$id";
    if($conn->query($sql)==TRUE){
		echo "Delete was successful!";
	}
	else{
		echo "Error while deleting.";
	}
}
?>

