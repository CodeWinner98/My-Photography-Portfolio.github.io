<?php
   include 'dbFunction.php'; // Include the database functions file
   
   // Call the show_booking() function to get booking details
   $bookings = show_booking();
   ?>
<!DOCTYPE html>
<html>
   <head>
      <title>My Photography Portfolio</title>
      <link rel="preconnect" href="https://fonts.googleapis.com">
      <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
      <link href="https://fonts.googleapis.com/css2?family=Kanit:ital,wght@1,300&family=MuseoModerno:wght@100&display=swap" rel="stylesheet">
      <link href="https://fonts.googleapis.com/css2?family=Grandstander&family=Kanit:ital,wght@0,500;0,700;1,300&family=MuseoModerno:wght@100&family=Rokkitt:wght@600&display=swap" rel="stylesheet">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
      <link rel="stylesheet" type="text/css" href="css/style.css">
      <link rel="stylesheet" type="text/css" href="css/gallery1.css">
      <link rel="stylesheet" type="text/css" href="css/contact.css">
      <!-- <link rel="stylesheet" type="text/css" href="css/bookform.css"> -->
      <link rel="stylesheet" type="text/css" href="css/slider.css">
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
      <style type="text/css">
         table{
         border:1px solid black;
         text-align: center;
         max-width: 500px;
         margin: 0 auto;
         padding: 20px;
         background-image: linear-gradient(to left bottom, #264e89, #006996, #007f85, #1d8f62, #7e9843);
         border-radius: 5px;
         box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
         }
         table,tr,td,th{
         padding: 5px;
         border:1px solid black;
         }
      </style>
   </head>
   <body>
      <header>
         <div class="logo">
            <img src="image/5.jpg" alt="Photography Logo"><br>
         </div>
         <nav>
            <a href="#home">Home</a>
            <a href="#about">About</a>
            <a href="#portfolio">Portfolio</a>
            <a href="#services">Services</a>
            <a href="#contact">Contact Us</a>
            <a href="#bknow">Book Now</a>
            <a href="#gallery">Gallery</a>
            <a href="index.php">Log Out</a>
         </nav>
      </header>
      <main >
         <section id="home">
            <h1>Welcome to My Photography Portfolio</h1>
            <p>Here you can explore my collection of stunning photographs showcasing various landscapes and subjects. Take a moment to browse through the different galleries and enjoy the artistry of photography.</p>
            <p>Welcome to my photography portfolio website. Explore my stunning collection of photographs capturing beautiful landscapes and captivating moments.</p>
            <div class="slider">
               <img src="image/5.jpg" alt="Image 2">
               <img src="image/8.jpg" alt="Image 2">
               <img src="image/9.jpg" alt="Image 3">
               <img src="image/10.jpg" alt="Image 4">
            </div>
         </section>
         <section id="about">
            <h2>About</h2>
            <p>Learn more about me and my passion for photography. Discover the stories behind my images and the techniques I use to create captivating photographs.</p>
            <div class="gallery">
               <div class="gallery-item">
                  <img src="image/7.jpg" alt="Image 1">
                  <div class="overlay">
                  </div>
               </div>
               <div class="gallery-item">
                  <img src="image/8.jpg" alt="Image 2">
                  <div class="overlay">
                  </div>
               </div>
               <div class="gallery-item">
                  <img src="image/9.jpg" alt="Image 1">
                  <div class="overlay">
                  </div>
               </div>
               <div class="gallery-item">
                  <img src="image/10.jpg" alt="Image 1">
                  <div class="overlay">
                  </div>
               </div>
            </div>
         </section>
         <section id="portfolio">
            <h2>Portfolio</h2>
            <p>View my extensive portfolio showcasing a wide range of subjects and styles. From nature and wildlife to portraits and architecture, you'll find a diverse collection of my best work.</p>
            <div class="photo-gallery">
               <img src="image/2.jpg" alt="Photograph 1">
            </div>
         </section>
         <section id="services">
            <h2>Services</h2>
            <p>View my extensive portfolio showcasing a wide range of subjects and styles. From nature and wildlife to portraits and architecture, you'll find a diverse collection of my best work.</p>
         </section>
         <section id="contact">
            <?php
               // Initialize variables for error messages
               $nameErr = $emailErr = $messageErr = "";
               $name = $email = $message = "";
               
               if ($_SERVER["REQUEST_METHOD"] == "POST") {
                   // Validate and sanitize name
                   if (empty($_POST["name"])) {
                       $nameErr = "Name is required";
                   } else {
                       $name = test_input($_POST["name"]);
                       if (!preg_match("/^[a-zA-Z ]*$/", $name)) {
                           $nameErr = "Only letters and spaces are allowed";
                       }
                   }
               
                   // Validate and sanitize email
                   if (empty($_POST["email"])) {
                       $emailErr = "Email is required";
                   } else {
                       $email = test_input($_POST["email"]);
                       if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                           $emailErr = "Invalid email format";
                       }
                   }
               
                   // Sanitize message (remove potential malicious code or tags)
                   if (empty($_POST["message"])) {
                       $messageErr = "Message is required";
                   } else {
                       $message = test_input($_POST["message"]);
                       $message = filter_var($message, FILTER_SANITIZE_STRING);
                   }
               }
               function test_input($data) {
                   $data = trim($data);
                   $data = stripslashes($data);
                   $data = htmlspecialchars($data);
                   return $data;
               }
               ?>
            <h2>Contact Us</h2>
            <form name="contactForm" method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
               <label for="name">Name:</label>
               <input type="text" id="name" name="name" value="<?php echo $name; ?>"><br>
               <span class="error"><?php echo $nameErr; ?></span><br><br>
               <label for="email">Email:</label>
               <input type="text" id="email" name="email" value="<?php echo $email; ?>"><br>
               <span class="error"><?php echo $emailErr; ?></span><br><br>
               <label for="message">Message:</label>
               <textarea name="message" id="message"><?php echo $message; ?></textarea><br>
               <span class="error"><?php echo $messageErr; ?></span><br><br>
               <button id="contact_btn" type="submit">Submit</button>
            </form>
            <script>
               document.getElementById("contact_btn").addEventListener("click", function() {
                   // Clear the input fields
                   document.getElementById("name").value = "";
                   document.getElementById("email").value = "";
                   document.getElementById("message").value = "";
                   
                   // Clear the error messages
                   var errorElements = document.querySelectorAll(".error");
                   for (var i = 0; i < errorElements.length; i++) {
                       errorElements[i].textContent = "";
                   }
               });
            </script>
            <script>
               document.getElementById("contact_btn").addEventListener("click", function(event) {
                   var nameInput = document.getElementById("name");
                   var emailInput = document.getElementById("email");
                   var messageInput = document.getElementById("message");
               
                   var nameErrElement = document.getElementById("nameErr");
                   var emailErrElement = document.getElementById("emailErr");
                   var messageErrElement = document.getElementById("messageErr");
               
                   // Reset error messages
                   nameErrElement.textContent = "";
                   emailErrElement.textContent = "";
                   messageErrElement.textContent = "";
               
                   // Validate and display errors
                   if (nameInput.value === "") {
                       nameErrElement.textContent = "Name is required.";
                       event.preventDefault();
                   }
               
                   if (emailInput.value === "") {
                       emailErrElement.textContent = "Email is required.";
                       event.preventDefault();
                   }
               
                   if (messageInput.value === "") {
                       messageErrElement.textContent = "Message is required.";
                       event.preventDefault();
                   }
               
                   });
            </script>
         </section>
         <section id="bknow">
         <h2>Book Now</h2>
         <div class="toggle-buttons">
            <button class="toggle-btn active" data-form="Book">Book Here</button>
            <button class="toggle-btn" data-form="View">View</button>
            <button class="toggle-btn" data-form="Update">Update</button>
            <button class="toggle-btn" data-form="Cancel">Cancel</button>
         </div>
         <div class="forms">
            <form id="Book" class="form active" action="process_form.php" method="POST">
               <label for="name">Name:</label>
               <input type="text" id="name" name="Name" required><br><br>
               <label for="phone">Phone:</label>
               <input type="text" id="phone" name="Tele_Number" required><br><br>
               <label for="address">Address:</label>
               <textarea name="Address" id="address" required ></textarea>
               <br><br>
               <label for="event">Event</label>
               <div class="event">
                  <input type="radio" name="Event" id="wedding" value="Wedding">
                  <label for="wedding">Wedding</label>
                  <input type="radio" name="Event" id="bd" value="Birthday">
                  <label for="bd">Birthday</label>
                  <input type="radio" name="Event" id="bride" value="Bride to be">
                  <label for="bride">Bride to be</label>
                  <input type="radio" name="Event" id="preshoot" value="Preshoot">
                  <label for="preshoot">Preshoot</label>
                  <input type="radio" name="Event" id="funoral" value="Funoral">
                  <label for="funoral">Funoral</label>
               </div>
               <br><br>
               <label for="date">Date:</label>
               <input type="date" name="Date" id="date"><br><br>
               <label for="email">Email:</label>
               <input type="email" id="email" name="Email" required><br><br>
               <label for="more">More</label>
               <textarea name="More" id="more" required></textarea>
               <br><br>
               <button type="submit" name="book" id="book">Book</button>
            </form>
            <h2>Booking Details</h2>
            <table id="View">
               <tr>
                  <th>ID</th>
                  <th>Name</th>
                  <th>Phone</th>
                  <th>Address</th>
                  <th>Event</th>
                  <th>Date</th>
                  <th>Email</th>
                  <th>More</th>
               </tr>
               <?php foreach ($bookings as $booking) { ?>
               <tr>
                  <td><?php echo $booking['ID']; ?></td>
                  <td><?php echo $booking['Name']; ?></td>
                  <td><?php echo $booking['Tele_Number']; ?></td>
                  <td><?php echo $booking['Address']; ?></td>
                  <td><?php echo $booking['Event']; ?></td>
                  <td><?php echo $booking['Date']; ?></td>
                  <td><?php echo $booking['Email']; ?></td>
                  <td><?php echo $booking['More']; ?></td>
               </tr>
               <?php } ?>
            </table>
            </form>
            <form id="Update" class="form" method="POST" action="process_form.php">
               <label for="id">ID:</label>
               <input type="text" name="id" id="id" placeholder="Enter ID for update booking details"><br><br>
               <label for="name">Name:</label>
               <input type="text" id="name" name="Name" ><br><br>
               <label for="phone">Phone:</label>
               <input type="text" id="phone" name="Tele_Number"><br><br>
               <label for="address">Address:</label>
               <textarea name="Address" id="address" ></textarea>
               <br><br>
               <label for="event">Event</label>
               <div class="event">
                  <input type="radio" name="Event" id="wedding" value="Wedding">
                  <label for="wedding">Wedding</label>
                  <input type="radio" name="Event" id="bd" value="Birthday">
                  <label for="bd">Birthday</label>
                  <input type="radio" name="Event" id="bride" value="Bride to be">
                  <label for="bride">Bride to be</label>
                  <input type="radio" name="Event" id="preshoot" value="Preshoot">
                  <label for="preshoot">Preshoot</label>
                  <input type="radio" name="Event" id="funoral" value="Funoral">
                  <label for="funoral">Funoral</label>
               </div>
               <br><br>
               <label for="date">Date:</label>
               <input type="date" name="Date" id="date"><br><br>
               <label for="email">Email:</label>
               <input type="email" id="email" name="Email" ><br><br>
               <label for="more">More</label>
               <textarea name="More" id="more"></textarea>
               <br><br>
               <button type="submit" name="update" id="update">Update</button>
            </form>
            <form id="Cancel" class="form" method="POST" action="process_form.php">
               <label for="id">ID:</label>
               <input type="text" name="id" id="id" placeholder="Enter ID for cancel booking"><br><br>
               <button type="submit" name="cancel" id="cancel">Cancel</button>
            </form>
         </div>
         <script>
            document.addEventListener("DOMContentLoaded", function () {
            const toggleButtons = document.querySelectorAll(".toggle-btn");
            const forms = document.querySelectorAll(".form");
            
            toggleButtons.forEach((button) => {
             button.addEventListener("click", function () {
                 const formId = this.getAttribute("data-form");
                 forms.forEach((form) => {
                     form.classList.remove("active");
                 });
                 document.getElementById(formId).classList.add("active");
                 toggleButtons.forEach((btn) => {
                     btn.classList.remove("active");
                 });
                 this.classList.add("active");
             });
            });
            });
            
         </script>
         <section id="gallery">
            <h2>Our Gallery</h2>
            <p>Here is photos gallery of my works.</p>
            <button id="toggleButton">View Gallery</button>
            <!-- Additional information to be toggled -->
            <div id="additionalInfo" style="display: none;">
               <div class="categories">
                  <button class="category-btn active" data-category="all">All</button>
                  <button class="category-btn" data-category="wedding">Wedding Album</button>
                  <button class="category-btn" data-category="family">Family Album</button>
                  <button class="category-btn" data-category="event">Event Album</button>
               </div>
               <div class="photos">
                  <div class="photo wedding">
                     <img src="image/about/1.jpg" alt="Wedding Photo 1">
                  </div>
                  <div class="photo family">
                     <img src="image//baby/1.jpg" alt="Family Photo 1">
                  </div>
                  <div class="photo event">
                     <img src="image/event/1.jpg" alt="Event Photo 1">
                  </div>
                  <div class="photo wedding">
                     <img src="image/about/3.jpg" alt="Wedding Photo 2">
                  </div>
                  <div class="photo family">
                     <img src="image/baby/2.jpg" alt="Family Photo 2">
                  </div>
                  <div class="photo event">
                     <img src="image/event/2.jpg" alt="Event Photo 2">
                  </div>
               </div>
            </div>
         </section>
      </main>
      <footer >
         <h3>Contact Details</h3>
         <p>Address: No.5,Maththegoda,Maharagama,SriLanka</p>
         <p>Phone: +94 113 678 456</p>
         <p>Email: rvaphotography@gmail.com</p>
         <p>Website: www.rvaphotography.com</p>
         <ul>
            <li><a href="#" class="fa fa-facebook"></a>
            <li><a href="#" class="fa fa-twitter"></a></li>
            <li><a href="#" class="fa fa-google"></a></li>
            <li><a href="#" class="fa fa-linkedin"></a></li>
            <li><a href="#" class="fa fa-youtube"></a></li>
            </li>
         </ul>
      </footer>
      <div class="fallen-leaves" aria-hidden="true">
         <div class="fallen-leaf">
            🍂
         </div>
         <div class="fallen-leaf">
            🍂
         </div>
         <div class="fallen-leaf">
            🍂
         </div>
         <!-- Add more fallen leaves here -->
      </div>
      <script src="js/leafflake.js"></script>
      <script type="text/javascript" src="js/category.js"></script>
      <script type="text/javascript" src="js/slider.js"></script>
      <!-- <script type="text/javascript" src="js/contact.js"></script> -->
      <script type="text/javascript">
         // Get the toggle button element
         const toggleButton = document.getElementById('toggleButton');
         
         // Get the additional information element
         const additionalInfo = document.getElementById('additionalInfo');
         
         // Add a click event listener to the toggle button
         toggleButton.addEventListener('click', function() {
           // Toggle the visibility of the additional information
           if (additionalInfo.style.display === 'none') {
             additionalInfo.style.display = 'block';
           } else {
             additionalInfo.style.display = 'none';
           }
         });
      </script>
      <script type="text/javascript">//smooth scrolling
         $(document).ready(function(){
             $("a").on('click', function(event) {
                 if (this.hash !== "") {
                     event.preventDefault();
         
                     var hash = this.hash;
                     var headerHeight = $("header").outerHeight(); // Get header height
         
                     $('html, body').animate({
                         scrollTop: $(hash).offset().top - headerHeight // Subtract header height from offset
                     }, 800, function(){
                         window.location.hash = hash;
                     });
                 }
             });
         });
         
         
           
      </script>
   </body>
</html>