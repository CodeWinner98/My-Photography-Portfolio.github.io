<?php


include 'dbFunction.php';

if (isset($_POST['book'])) {

    $name = $_POST['Name'];
	$tele = $_POST['Tele_Number'];
	$addr = $_POST['Address'];
	$event= $_POST['Event'];
	$date = $_POST['Date'];
	$email= $_POST['Email'];
	$more = $_POST['More'];

   insert_booking($name,$tele,$addr,$event,$date,$email,$more );

}

if (isset($_POST['view'])) {
	show_booking();

}

if (isset($_POST['update'])) {
	$id = $_POST['id'];
	$name = $_POST['Name'];
	$tele = $_POST['Tele_Number'];
	$addr = $_POST['Address'];
	$event= $_POST['Event'];
	$date = $_POST['Date'];
	$email= $_POST['Email'];
	$more = $_POST['More'];

	update_booking($id,$name,$tele,$addr,$event,$date,$email,$more);
}

if (isset($_POST['cancel'])) {
	$id = $_POST['id'];

	delete_booking($id);
}


?>