<?php
// Database credentials
$host = 'localhost';
$username = 'root';
$password = '';
$db = 'myweb_db';

// Retrieve form data
$name =$_POST['name'];
$email =$_POST['email'];
$phone =$_POST['phone'];
$address =$_POST['address'];
$event =$_POST['event'];
$date =$_POST['date'];
$more =$_POST['more'];

// Create connection
$conn = new mysqli($host, $username, $password, $db);

// Check connection
if ($conn->connect_error) {
    die("Connection Failed: " . $conn->connect_error);
}

// Prepare and bind the INSERT statement with placeholders to avoid SQL injection
$sql = "INSERT INTO book (name, email, contact, address, event, date, more) VALUES (?, ?, ?, ?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("sssssss", $name, $email, $phone, $address, $event, $date, $more);

// Execute the prepared statement
if ($stmt->execute()) {
    echo "FORM SUBMITTED...!!";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

// Close the prepared statement and DB connection
$stmt->close();
$conn->close();
?>
